import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nnn',
  templateUrl: './nnn.component.html',
  styleUrls: ['./nnn.component.css']
})
export class NnnComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
