import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { NnnComponent } from './nnn/nnn.component';
import { MmmComponent } from './mmm/mmm.component';

@NgModule({
  declarations: [
    AppComponent,
    NnnComponent,
    MmmComponent,
   
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
