import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mmm',
  templateUrl: './mmm.component.html',
  styleUrls: ['./mmm.component.css']
})
export class MmmComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
