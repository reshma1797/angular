import { Component, ɵConsole } from '@angular/core';

@Component({
  selector: 'avnish',
  templateUrl: './app.component.html',
  styleUrls: []
})
export class AppComponent {
  title = 'project';


  public value=true;
public ajay="ajay";

  getValue(){
    return this.value;
  }

  onClick(){
    this.value = !this.value;
    console.log(this.value);
  }
}
